package pages.Alper;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

public class MainLoginPage {
    public MainLoginPage() {
        PageFactory.initElements(Driver.getDriver(), this);
    }
    @FindBy (xpath ="//a[@href ='/login']" ) public WebElement login;
    @FindBy (id="username") public WebElement UserName;
    @FindBy (id="password")  public WebElement Password;

    @FindBy (xpath = " //button [@class='fw-semibold btn btn-primary'] " ) public WebElement loginButton;
    @FindBy (xpath ="//*[@id=\"root\"]/div/main/div/div[1]/div/form/div[3]/button")  public WebElement LoginButton;
    @FindBy (xpath = "//button [@class='fw-semibold btn btn-primary']" ) public WebElement Login;



    @FindBy(xpath = "//a[@class = 'header_link me-2']")
    public WebElement registerLink;
    @FindBy(xpath = "//*[@href='/login']") public WebElement loginLink;
    @FindBy(id = "username") public WebElement usernameBox;
    @FindBy(id = "password") public WebElement passwordBox;

}
