package pages.Alper;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;


public class ViceDeanManagamentPage {
    public ViceDeanManagamentPage(){
        PageFactory.initElements(Driver.getDriver(),this);
    }
    @FindBy(id = "name") public WebElement name;
    @FindBy(id = "surname") public WebElement surname;
    @FindBy(id = "birthPlace") public WebElement birthPlace;
    @FindBy(xpath = "//input[@value=\"MALE\"]") public WebElement maleRadioButton;
    @FindBy(id = "birthDay") public WebElement birthDay;
    @FindBy(id = "phoneNumber") public WebElement phoneNumber;
    @FindBy(id = "ssn") public WebElement ssn;
    @FindBy(id = "username") public WebElement username;
    @FindBy(id = "password") public WebElement password;
    @FindBy(xpath = "//button[contains(text(),'Submit')]") public WebElement submitButton;

    @FindBy(xpath = "//div[@class='Toastify__toast-container Toastify__toast-container--top-center']")
    public WebElement validationAlert;

    @FindBy(xpath = "//div[@role='alert']//div[normalize-space()='Please enter valid SSN number']")
    public WebElement alertMessageEnterValidSsnNumber;

    //HALIL
    @FindBy(xpath = "//button[contains(text(),'Menu')]") public WebElement menuButton;
    @FindBy(xpath = "//a[contains(text(),'Lesson Management')]") public WebElement lessonManagementButton;
    @FindBy(xpath = "//button[@id='controlled-tab-example-tab-lessonsList']") public WebElement lessonButton;
    @FindBy(xpath = "//input[@id='lessonName']") public WebElement lessonName;
    @FindBy(xpath = "//input[@id='compulsory']") public WebElement compulsory;
    @FindBy(xpath = "//input[@id='creditScore']") public WebElement creditScore;
    @FindBy(xpath = "//body/div[@id='root']/div[1]/main[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/form[1]/div[1]/div[4]/div[1]/button[1]") public WebElement lessonSubmitButton;
    @FindBy(xpath = "//body/div[@id='root']/div[1]/main[1]/div[1]/div[2]") public WebElement toastifyAlert;
    @FindBy(xpath = "//body/div[@id='root']/div[1]/main[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/ul[1]/li[5]/a[1]/span[1]") public WebElement lastPage;

    @FindBy(xpath = "//th[contains(text(),'Lesson Name')]") public WebElement lessonNameVerify;
    @FindBy(xpath = "//th[contains(text(),'Compulsory')]") public WebElement compulsoryVerify;
    @FindBy(xpath = "//th[contains(text(),'Credit Score')]") public WebElement creditScoreVerify;
    @FindBy(xpath = "//body/div[@id='root']/div[1]/main[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/h5[1]") public WebElement addLessonSession;

    @FindBy(xpath = "//tbody/tr[1]/td[4]/span[1]/button[1]/i[1]") public WebElement deleteButton;




    @FindBy(xpath="//*[@id=\"controlled-tab-example-tab-lessonProgram\"]") public WebElement lessonProgramViceDean;

    @FindBy(xpath="//body/div[@id='root']/div[1]/main[1]/div[1]/div[1]/div[1]/div[3]/div[2]/div[1]/div[1]/form[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]") public WebElement selectLessonViceDean;

    @FindBy(xpath = "//input [@id='react-select-2-input']") public WebElement getSelectLessonViceDean;

    @FindBy(xpath="//div[contains(text(),'Java')]") public WebElement selectedLessonViceDean;

    @FindBy(xpath = "//select[@id='educationTermId']")   public WebElement chooseEducationTermViceDean;


    @FindBy(xpath = "//select[@id='day']")   public WebElement chooseDayViceDean;

    @FindBy(xpath = "//option[@value='MONDAY']")  public WebElement selectDayNameViceDean;

    @FindBy(xpath = "//input[@id='startTime']")   public WebElement chooseStartTimeViceDean;

    @FindBy(xpath = "//input[@id='stopTime']")   public WebElement chooseStopTimeViceDean;

    @FindBy(xpath = ("//body/div[@id='root']/div[1]/main[1]/div[1]/div[1]/div[1]/div[3]/div[2]/div[1]/div[1]/form[1]/div[1]/div[2]/div[3]/div[1]/button[1]"))
    public WebElement addLessonSubmitViceDean;

    @FindBy(xpath = "//div[contains(text(),'Created Lesson Program')]") public WebElement lessonSuccessfullyCreatedMessageViceDean;


    @FindBy(xpath = "//div[@class='col']//th[contains(text(),'Day')]") public WebElement dayTableDean;
    
    @FindBy(xpath = "//div[@class='col']//th[contains(text(),'Start Time')]")  public WebElement startTimeTableDean;
    
    @FindBy(xpath = "//div[@class='col']//th[contains(text(),'Stop Time')]")  public WebElement stopTimeTableDean;

    @FindBy(xpath = "//body/div[@id='root']/div[1]/main[1]/div[1]/div[1]/div[1]/div[3]/div[2]/div[2]/div[1]/div[1]/table[1]") public WebElement lessonProgramListViceDean;

    @FindBy(xpath = "//tbody/tr[1]/td[1]/span[1]/div[1]/input[1]") public WebElement createdLessonCheckbox;
    
    @FindBy(xpath = "//select[@id='teacherId']") public WebElement chooseTeacher;

    @FindBy(xpath = " (//button[@class= 'fw-semibold btn btn-primary btn-lg'])[4]") public WebElement submitTeacherForChosenLesson;
    @FindBy(partialLinkText = "Teacher Management") public WebElement teacherManagementOption;

    
    
    @FindBy(xpath = "//div[contains(text(),'Lesson added to Teacher')]") public WebElement lessonAddedToTeacherViceDean;


}
