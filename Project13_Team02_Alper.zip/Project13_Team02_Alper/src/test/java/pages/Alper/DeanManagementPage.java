package pages.Alper;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DeanManagementPage {

    @FindBy(xpath = "//button[text()='Menu']")
    public WebElement menuButton;

    @FindBy(xpath = "//a[text()='Dean Management']")
    public WebElement deanManagementButton;

    @FindBy(id = "name")
    public WebElement name;

    @FindBy(id = "surname")
    public WebElement surname;

    @FindBy(id = "birthPlace")
    public WebElement birthPlace;

    @FindBy(xpath = "//input[@value='FEMALE']")
    public WebElement genderFemale;

    @FindBy(xpath = "//input[@value='MALE']")
    public WebElement genderMale;

    @FindBy(id = "birthDay")
    public WebElement birthDay;

    @FindBy(id = "phoneNumber")
    public WebElement phoneNumber;

    @FindBy(id = "ssn")
    public WebElement ssn;

    @FindBy(id = "username")
    public WebElement username;

    @FindBy(id = "password")
    public WebElement deanPassword;

    @FindBy(css = ".btn-primary")
    public WebElement deanSubmit;

    @FindBy(xpath = "//div[@class='Toastify__toast-body']/div[.='Dean Saved']")
    public WebElement deanSavedPopUp;

    @FindBy(xpath = "//form[1]/div[@class='row']/div[1]//div[@class='invalid-feedback']")
    public WebElement deanNameRequired;

    @FindBy(xpath = "//form[1]//div[2]//div[@class='invalid-feedback']")
    public WebElement deanSurNameRequired;

    @FindBy(xpath = "//form[1]//div[3]//div[@class='invalid-feedback']")
    public WebElement deanBirthPlaceBoxRequired;

    @FindBy(xpath = "//div[@class='Toastify__toast-body']/div[contains(.,'JSON parse error: Cannot coerce empty String (\"\") to `com.project.schoolmanagmen')]")
    public WebElement deanGenderBoxRequired;

    @FindBy(xpath = "//*[@id=\"root\"]/div/main/div/div[1]/div[2]/div[1]/div/form/div/div[6]/div/div")
    public WebElement deanDateOfBirthBoxRequired;

    @FindBy(xpath = "//*[@id=\"root\"]/div/main/div/div[1]/div[2]/div[1]/div/form/div/div[6]/div/div")
    public WebElement deanPhoneNumberBoxRequired;

    @FindBy(xpath = "//div[@class='Toastify__toast-body']/div[.='Please enter valid SSN number']")
    public WebElement deanSSNBoxRequired;

    @FindBy(xpath = "//div[.='Required']")
    public WebElement deanUserNameBoxRequired;

    @FindBy(xpath = "//div[.='Minimum 8 character']")
    public WebElement deanPasswordBoxRequired;

    @FindBy(xpath = "//div[normalize-space()='Minimum 11 character (XXX-XX-XXXX)']")
    public WebElement deanSSNMinCharRequired;

    @FindBy(xpath = "//*[@id=\"root\"]/div/main/div/div[1]/div[2]/div[1]/div/form/div/div[9]/div/div")
    public WebElement deanPasswordMin8CharReq;

    @FindBy(xpath = "//*[@id=\"root\"]/div/main/div/div[1]/div[2]/div[1]/div/form/div/div[9]/div/div")
    public WebElement deanPasswordOneUppercaseCharReq;

    @FindBy(xpath = "//*[@id=\"root\"]/div/main/div/div[1]/div[2]/div[1]/div/form/div/div[9]/div/div")
    public WebElement deanPasswordOneLowercaseCharReq;

    @FindBy(xpath = "//*[@id=\"root\"]/div/main/div/div[1]/div[2]/div[1]/div/form/div/div[9]/div/div")
    public WebElement deanPasswordOneNumberReq;

    @FindBy(xpath = "/html/body")
    public WebElement genderInvalidPopUp;

}

