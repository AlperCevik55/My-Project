package pages.Alper;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

public class RegistrationPage {
    public RegistrationPage() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(id = "name") public WebElement name;
    @FindBy(id="surname") public WebElement surname;
    @FindBy(id="birthPlace") public WebElement birthPlace;
    @FindBy(id="phoneNumber") public WebElement phoneNumber;
    @FindBy(xpath="//input[@value='FEMALE']") public WebElement radioButtonFemale;
    @FindBy(xpath="//input[@value='MALE']") public WebElement radioButtonMale;
    @FindBy(id="ssn") public WebElement ssn;
    @FindBy(id="password") public WebElement password;
    @FindBy(xpath ="//div[@class='Toastify__toast-body']/div[.='Guest User registered.']") public WebElement UserRegisteredMessage;
    @FindBy(xpath ="(//div[@class='invalid-feedback'])[1]") public WebElement requiredMessageForName;
    @FindBy(xpath ="(//div[@class='invalid-feedback'])[2]") public WebElement requiredMessageForSurname;
    @FindBy(xpath ="(//div[@class='invalid-feedback'])[3]") public WebElement requiredMessageForBirthplace;
    @FindBy(xpath ="//div[@class='invalid-feedback' and text()='Minimum 11 character (XXX-XX-XXXX)']") public WebElement characterMessageForSsn;
    @FindBy(xpath ="//div[@class='invalid-feedback' and text()='At least 8 characters']") public WebElement characterMessageForPwd;
    @FindBy(xpath ="//div[@class='invalid-feedback' and text()='One uppercase character']") public WebElement uppercaseMessageForPwd;
    @FindBy(xpath ="//div[@class='invalid-feedback' and text()='One lowercase character']") public WebElement lowercaseMessageForPwd;
    @FindBy(xpath ="//div[@class='invalid-feedback' and text()='One number']") public WebElement numberMessageForPwd;


}
