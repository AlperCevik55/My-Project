package pages.Alper;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

public class TeacherManagementPage {
    public TeacherManagementPage() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(xpath = " //button[@class='fw-semibold text-white bg-primary navbar-toggler collapsed'] " ) public WebElement Menu;
    @FindBy (xpath = " //a[.='Meet Management'] " ) public WebElement MeetManagement;
    @FindBy (xpath = " //div[@id='react-select-2-placeholder'] ") public WebElement SelectStudent;
    @FindBy (id="date") public WebElement DateMeet;
    @FindBy (id="startTime") public WebElement StartTime;
    @FindBy (id="stopTime") public WebElement StopTime;
    @FindBy (id="description") public WebElement Description;
    @FindBy (xpath = " //button[@class='fw-semibold btn btn-primary btn-lg'] ") public WebElement Submit;

    @FindBy(xpath = "//input[@id='react-select-2-input']")
    public WebElement chooseLessonDropdown;

    @FindBy(xpath = "//div[@class=' css-19bb58m']")
    public WebElement geometryOption;

    @FindBy(id = "name")
    public WebElement nameInput;

    @FindBy(id = "surname")
    public WebElement surnameInput;

    @FindBy(id = "birthPlace")
    public WebElement birthPlaceInput;

    @FindBy(id = "email")
    public WebElement emailInput;

    @FindBy(id = "phoneNumber")
    public WebElement phoneNumberInput;

    @FindBy(id = "isAdvisorTeacher")
    public WebElement isAdvisorTeacherOption;

    @FindBy(xpath = "//input[@value='MALE']")
    public WebElement genderOptionMale;

    @FindBy(xpath = "//input[@value='FEMALE']")
    public WebElement genderOptionFemale;

    @FindBy(id = "birthDay")
    public WebElement dateOfBirthInput;

    @FindBy(id = "ssn")
    public WebElement ssnInput;

    @FindBy(id = "username")
    public WebElement teacherUsernameInput;

    @FindBy(id = "password")
    public WebElement teacherPasswordInput;

    @FindBy(xpath = "//button[@class='fw-semibold btn btn-primary btn-lg']")
    public WebElement submitButton;
}
