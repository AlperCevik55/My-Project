package pages.Alper;

//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class GuestUserPage {

    @FindBy(linkText = "(//main[@class='content']//li[5]//a[1]")
    public WebElement lastArrow;

    @FindBy(xpath = "//th[text()='Name']")
    public WebElement name;

    @FindBy(xpath = "//th[text()='Phone Number']")
    public WebElement phone;

    @FindBy(xpath = "//th[text()='Ssn']")
    public WebElement ssn;

    @FindBy(xpath = "//th[text()='User Name']")
    public WebElement user;

    @FindBy(xpath = "(//button[@class='btn btn-danger'])[1]")
    public WebElement deleteButton;

    @FindBy(xpath = "(//table[@class='table table-striped table-bordered table-hover'])//tr")
    public List<WebElement> tableRowList;

    //private WebDriver driver;

    //public GuestUserPage(WebDriver driver) {
        //this.driver = driver;
        //PageFactory.initElements(driver, this);
   // }

    // Add methods for interacting with these elements

    public void clickLastArrow() {
        lastArrow.click();
    }

    public String getNameColumnText() {
        return name.getText();
    }

    public String getPhoneColumnText() {
        return phone.getText();
    }

    public String getSsnColumnText() {
        return ssn.getText();
    }

    public String getUserColumnText() {
        return user.getText();
    }

    public void clickDeleteButton() {
        deleteButton.click();
    }

    public int getTableRowCount() {
        return tableRowList.size();
    }

    // Add more methods as needed based on your application's functionality
}

