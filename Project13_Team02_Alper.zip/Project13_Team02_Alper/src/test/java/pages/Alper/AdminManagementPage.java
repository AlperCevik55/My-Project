package pages.Alper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

import org.openqa.selenium.support.FindBy;

public class AdminManagementPage {

 

    public AdminManagementPage() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy (xpath="//*[@id='name']") public WebElement addAdminName;
    @FindBy (xpath="//*[@id='surname']") public WebElement addAdminSurName;
    @FindBy (xpath="//*[@id='birthPlace']") public WebElement addAdminBirthPlace;
    @FindBy (xpath="(//*[@name='gender'])[1]") public WebElement addAdminGender;
    @FindBy (xpath="/*[@id='birthDay']") public WebElement addAdminDateOfBirth;
    @FindBy (xpath="//*[@id='phoneNumber']") public WebElement addAdminPhone;
    @FindBy (xpath="//*[@id='ssn']") public WebElement addAdminSnn;
    @FindBy (xpath="//*[@id='username']") public WebElement addAdminUserName;
    @FindBy (xpath="//*[@id='password']") public WebElement addAdminPassword;
    @FindBy (xpath="//*[@class='navbar'] //*[@aria-label='Toggle navigation']") public WebElement mainMenu;
    @FindBy (xpath="(//*[@role='dialog'] //*[@role='button'])[1]") public WebElement adminManagementTab;
    @FindBy (xpath="(//*[@class='invalid-feedback'])[1]]") public WebElement requiredAdminName;
    @FindBy (xpath="(//*[@class='invalid-feedback'])[2]") public WebElement requiredAdminSurName;
    @FindBy (xpath="(//*[@class='invalid-feedback'])[3]") public WebElement requiredAdminBirthPlace;
    @FindBy (xpath="(//*[@class='invalid-feedback'])[4]") public WebElement requiredAdminDateOfBirth;
    @FindBy (xpath="(//*[@class='invalid-feedback'])[5]") public WebElement requiredAdminPhone;
    @FindBy (xpath="(//*[@class='invalid-feedback'])[6]") public WebElement requiredAdminSnn;
    @FindBy (xpath="(//*[@class='invalid-feedback'])[7]]") public WebElement requiredAdminUserName;
    @FindBy (xpath="(//*[@class='invalid-feedback'])[8]]") public WebElement requiredAdminPassword;
    @FindBy (xpath="(//*[@class='invalid-feedback'])[9]]") public WebElement requiredGender;
    @FindBy (xpath="//*[@class='fw-semibold btn btn-primary btn-lg']") public WebElement adminSubmitButton;
    @FindBy(xpath = "//button[contains(text(),'Menu')]") public WebElement menuButton;
    @FindBy(xpath = "//a[contains(text(),'Vice Dean Management')]") public WebElement viceDeanManagementButton;
    @FindBy(partialLinkText = "Teacher Management") public WebElement teacherManagementOption;

    @FindBy(xpath = "//h3[@bg='primary']") public WebElement adminManagementTitle;


}





