package pages.Alper;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

public class StudentInfoPage {
    public StudentInfoPage() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(xpath = "(//td//span)[1]") public WebElement name;
    @FindBy(xpath = "(//span[ text() = .])[3]") public WebElement lessonName;
    @FindBy(xpath = "(//span[ text() = .])[4]") public WebElement absentee;
    @FindBy(xpath = "(//span[ text() = .])[5]") public WebElement midtermExam;
    @FindBy(xpath = "(//span[ text() = .])[6]") public WebElement finalExam;
    @FindBy(xpath = "(//span[ text() = .])[7]") public WebElement note;
    @FindBy(xpath = "(//span[ text() = .])[8]") public WebElement infoNote;
    @FindBy(xpath = "(//span[ text() = .])[9]") public WebElement average;
    @FindBy(xpath = "//button[@class='text-dark btn btn-outline-info']") public WebElement editButton;
    @FindBy(xpath = "(//input[@placeholder='Midterm Exam'])[2]") public WebElement editMidterm;
    @FindBy(xpath = "(//button[text() ='Submit'])[2]") public WebElement submitButton;
    @FindBy(xpath = "//button[@class='btn btn-danger']") public WebElement deleteButton;
}
