package pages.Alper;

//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ContactPage {

    @FindBy(xpath = "//a[.='Contact']")
    public WebElement contact;

    @FindBy(xpath = "//input[@id='name']")
    public WebElement yourName;

    @FindBy(xpath = "//input[@id='email']")
    public WebElement yourEmail;

    @FindBy(xpath = "//input[@id='subject']")
    public WebElement subject;

    @FindBy(xpath = "//textarea[@id='message']")
    public WebElement message;

    @FindBy(xpath = "//button[@class='fw-semibold btn btn-primary']")
    public WebElement sendMessage;

    @FindBy(xpath = "//div[@class='Toastify__toast-container Toastify__toast-container--top-center']")
    public WebElement alertMessageSuccess;

    @FindBy(xpath = "//div[contains(text(),'Please enter valid email')]")
    public WebElement alertMessageFailed;


    public void clickContactLink() {
        contact.click();
    }

    public void enterYourName(String name) {
        yourName.sendKeys(name);
    }

    public void enterYourEmail(String email) {
        yourEmail.sendKeys(email);
    }

    public void enterSubject(String subjectText) {
        subject.sendKeys(subjectText);
    }

    public void enterMessage(String messageText) {
        message.sendKeys(messageText);
    }

    public void clickSendMessage() {
        sendMessage.click();
    }

    public String getAlertMessageSuccessText() {
        return alertMessageSuccess.getText();
    }

    public String getAlertMessageFailedText() {
        return alertMessageFailed.getText();
    }
}

