package pages.Alper;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

public class SchoolLoginPage {
    public SchoolLoginPage() {
        PageFactory.initElements(Driver.getDriver(), this);
    }
    @FindBy(xpath = "//a[@class = 'header_link ms-2']")
    public WebElement loginLink;

    @FindBy(id = "username")
    public WebElement loginUserNameInput;

    @FindBy(id = "password")
    public WebElement loginPasswordInput;

    @FindBy(xpath = "//button[@class='fw-semibold btn btn-primary']")
    public WebElement loginButton;



}
