package pages.Alper;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

public class StudentManagementPage {
    public StudentManagementPage() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(xpath = " //input[@id='lessonProgramId'] " ) public WebElement LessonTickBox;
    @FindBy (xpath = "//input[@value='1369'] " ) public WebElement MondayLesson;
    @FindBy (xpath = "//input[@value='1377'] " ) public WebElement MondayLessonS;
    @FindBy (xpath = "//input[@value='1371'] ") public WebElement TuesdayLesson;
    @FindBy (xpath = " //button[@class='fw-semibold btn btn-primary btn-lg'] " ) public WebElement submitButton;
    @FindBy (xpath = " //button[@class='fw-semibold text-white bg-primary navbar-toggler collapsed'] ") public WebElement StudentMenu;
    @FindBy (xpath = " //a[.='Grades and Announcements'] ") public WebElement GradesAnnouncement;

    @FindBy(xpath = "//button[@class='fw-semibold text-white bg-primary navbar-toggler collapsed']")
    public WebElement menuOption;

    @FindBy(xpath = "//a[text()='Student Management']")
    public WebElement StudentManagementOption;
    @FindBy(id = "advisorTeacherId")
    public WebElement teacherDropdown;
    @FindBy(id = "name")
    public WebElement nameInput;
    @FindBy(id = "surname")
    public WebElement surnameInput;
    @FindBy(id = "birthPlace")
    public WebElement birthPlaceInput;
    @FindBy(id = "birthDay")
    public WebElement dateOfBirthInput;

    @FindBy(id = "email")
    public WebElement emailInput;
    @FindBy(id = "phoneNumber")
    public WebElement phoneNumberInput;

    @FindBy(name = "gender")
    public WebElement genderRadio;
    @FindBy(id = "ssn")
    public WebElement ssnInput;
    @FindBy(id = "username")
    public WebElement studentUserNameInput;
    @FindBy(id = "fatherName")
    public WebElement fatherNameInput;
    @FindBy(id = "motherName")
    public WebElement motherNameInput;
    @FindBy(xpath = "//input[@type='password']")
    public WebElement studentPasswordInput;

   @FindBy(xpath = "//*[@class='Toastify__toast-body']") public WebElement pleaseEnterValidSSNMessage;

    @FindBy(xpath ="//div[text()='Minimum 11 character (XXX-XX-XXXX)']") public WebElement ssnMinimumCharacterMessage;
    @FindBy(xpath = "//tr[last()]/td[1]") public static WebElement firstColumnInLastRow;
    @FindBy(xpath = "//*[.='One uppercase character']") public WebElement passwordWithoutUpperCaseErrorMessage;
    @FindBy(xpath = "//*[.='At least 8 characters']") public WebElement passwordLessCharErrorMessage;
    @FindBy(xpath = "//option[@value='2179']") public WebElement advisorTeacherMerle;
    @FindBy(xpath = "//*[@value='MALE']") public WebElement genderMale;
    @FindBy(xpath = "//*[@value='FEMALE']") public WebElement genderFemale;
@FindBy(xpath = "//*[@role='alert']") public WebElement confirmationMessage;
        @FindBy(xpath = "//a[@class='page-link' and contains(., 'Last')]") public WebElement goLastPageButton;

    @FindBy(xpath = "//table//tbody//tr[last()]") public WebElement lastRow;

}
