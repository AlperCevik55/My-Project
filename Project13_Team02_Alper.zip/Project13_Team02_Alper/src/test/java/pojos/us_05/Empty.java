package pojos.us_05;

public class Empty {
}
