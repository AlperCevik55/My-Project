package pojos.us_03;

public class Empty {
}
