package pojos.us_07;

public class Empty {
}
