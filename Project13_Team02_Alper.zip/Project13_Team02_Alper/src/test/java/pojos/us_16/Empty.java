package pojos.us_16;

public class Empty {
}
