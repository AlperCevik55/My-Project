package pojos.us_20;

public class Empty {
}
