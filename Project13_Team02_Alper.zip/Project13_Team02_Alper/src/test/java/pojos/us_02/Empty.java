package pojos.us_02;

public class Empty {
}
