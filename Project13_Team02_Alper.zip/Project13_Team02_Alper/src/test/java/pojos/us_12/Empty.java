package pojos.us_12;

public class Empty {
}
