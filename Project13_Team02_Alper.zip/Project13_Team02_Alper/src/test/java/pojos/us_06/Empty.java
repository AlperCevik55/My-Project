package pojos.us_06;

public class Empty {
}
