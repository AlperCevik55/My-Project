package pojos.us_08;

public class Empty {
}
