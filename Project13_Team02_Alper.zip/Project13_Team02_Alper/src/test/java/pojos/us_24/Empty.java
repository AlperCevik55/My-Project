package pojos.us_24;

public class Empty {
}
