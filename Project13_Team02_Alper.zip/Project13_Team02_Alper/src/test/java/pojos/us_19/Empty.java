package pojos.us_19;

public class Empty {
}
