package pojos.us_22;

public class Empty {
}
