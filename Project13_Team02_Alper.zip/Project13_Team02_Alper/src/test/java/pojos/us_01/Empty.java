package pojos.us_01;

public class Empty {
}
