package pojos.us_09;

public class Empty {
}
