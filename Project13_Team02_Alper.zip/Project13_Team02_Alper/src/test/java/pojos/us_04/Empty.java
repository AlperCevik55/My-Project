package pojos.us_04;

public class Empty {
}
