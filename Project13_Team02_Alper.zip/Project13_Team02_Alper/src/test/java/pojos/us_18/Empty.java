package pojos.us_18;

public class Empty {
}
