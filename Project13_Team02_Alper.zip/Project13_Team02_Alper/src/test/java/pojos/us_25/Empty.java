package pojos.us_25;

public class Empty {
}
