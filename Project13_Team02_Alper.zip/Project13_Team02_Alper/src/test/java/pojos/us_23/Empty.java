package pojos.us_23;

public class Empty {
}
