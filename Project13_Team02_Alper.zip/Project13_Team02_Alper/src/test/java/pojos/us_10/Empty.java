package pojos.us_10;

public class Empty {
}
