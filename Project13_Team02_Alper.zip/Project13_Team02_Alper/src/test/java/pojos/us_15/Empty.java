package pojos.us_15;

public class Empty {
}
