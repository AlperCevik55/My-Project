package stepdefinitions.us_06;

public class Empty {
}
