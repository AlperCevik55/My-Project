package stepdefinitions.us_02;

public class Empty {
}
