package stepdefinitions.us_24;

public class Empty {
}
