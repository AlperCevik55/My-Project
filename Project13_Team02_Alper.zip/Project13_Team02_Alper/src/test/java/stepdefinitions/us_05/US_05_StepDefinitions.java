package stepdefinitions.us_05;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class US_05_StepDefinitions {



    @Given("an admin is logged in")
    public void adminIsLoggedIn() {
        // Implementation for logging in as an admin
    }

    @When("the admin navigates to the Deans management page")
    public void adminNavigatesToDeansManagementPage() {
        // Implementation for navigating to the Deans management page
    }

    @Then("the admin should be able to see the Name, Gender, Phone Number, SSN, and User Name columns in the Deans list")
    public void adminShouldSeeDeansListColumns() {
        // Implementation for verifying that the admin can see the specified columns

    }

    @Then("the admin should be able to see information in the Deans list")
    public void adminShouldSeeDeansInfo() {
        // Implementation for verifying that the admin can see information in the Deans list

    }

    @When("the admin selects a Dean and clicks the delete button")
    public void adminDeletesDean() {
        // Implementation for deleting a Dean

    }

    @Then("the Dean should be successfully deleted")
    public void deanShouldBeDeletedSuccessfully() {
        // Implementation for verifying that the Dean is successfully deleted

    }

    @When("the admin selects a Dean and updates the information")
    public void adminUpdatesDeanInfo() {
        // Implementation for updating Dean information

    }

    @Then("the Dean information should be successfully updated")
    public void deanInfoShouldBeUpdatedSuccessfully() {
        // Implementation for verifying that the Dean information is successfully updated

    }
}

