package stepdefinitions.us_08;

public class Empty {
}
