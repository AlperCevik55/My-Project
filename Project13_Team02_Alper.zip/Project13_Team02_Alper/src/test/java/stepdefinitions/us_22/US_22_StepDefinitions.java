package stepdefinitions.us_22;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import pages.Alper.AdminManagementPage;
import pages.Alper.MainLoginPage;
import utilities.Driver;
import utilities.WaitUtils;

public class US_22_StepDefinitions {


        AdminManagementPage adminManagement = new AdminManagementPage();
        MainLoginPage mainLoginPage = new MainLoginPage();

        @Given("go to homepage {string}_SC")
        public void go_to_homepage__sc(String string) {
            Driver.getDriver().get("https://managementonschools.com/");
        }

        @When("click on login button_SC")
        public void click_on_login_button_sc() {
            mainLoginPage.login.click();
            WaitUtils.waitFor(2);
            mainLoginPage.UserName.sendKeys("AdminProject13");
            mainLoginPage.Password.sendKeys("Project13+");
            mainLoginPage.loginButton.click();
            WaitUtils.waitFor(10);

        }

        @When("Click on main menu button_SC")
        public void click_on_main_menu_button_sc() {
            adminManagement.mainMenu.click();
        }

        @When("Choose the {string} option from the list_SC")
        public void choose_the_option_from_the_list_sc(String string) {
            adminManagement.adminManagementTab.click();
        }

        @When("Enter a valid name,surname,place of birth, date of birth,ssn number, phone number and check the gender button_SC")
        public void enter_a_valid_name_surname_place_of_birth_date_of_birth_ssn_number_phone_number_and_check_the_gender_button_sc() {
            adminManagement.addAdminName.sendKeys("Sandy", Keys.TAB, "Warren", Keys.TAB, "Mishigan", Keys.TAB, Keys.TAB,
                    "12/12/1972", Keys.TAB, "440-432-2215", Keys.TAB, "780-15-4445", Keys.TAB,
                    "AdminProject11", Keys.TAB, "Project23+");
            adminManagement.addAdminGender.click();


        }

        @When("Click on submit button_SC")
        public void click_on_submit_button_sc() {
            adminManagement.adminSubmitButton.click();
        }

        @Then("Verify that {string} message is displayed_SC")
        public void verify_that_message_is_displayed_sc(String successMessage) {
            Assert.assertEquals(successMessage, Driver.getDriver().switchTo().alert().getText());
        }

        @And("Verify that the  name, surname,place of birth, date of birth,ssn number, phone number,username and password fields red out when left blank and give empty field error.")
        public void verifyThatTheNameSurnamePlaceOfBirthDateOfBirthSsnNumberPhoneNumberUsernameAndPasswordFieldsRedOutWhenLeftBlankAndGiveEmptyFieldError() {
            Assert.assertEquals("Required", adminManagement.requiredAdminName.getText());
            Assert.assertEquals("Required", adminManagement.requiredAdminSurName.getText());
            Assert.assertEquals("Required", adminManagement.requiredAdminBirthPlace.getText());
            Assert.assertEquals("Required", adminManagement.requiredAdminDateOfBirth.getText());
            Assert.assertEquals("Required", adminManagement.requiredAdminPhone.getText());
            Assert.assertEquals("Required", adminManagement.requiredAdminSnn.getText());
            Assert.assertEquals("Required", adminManagement.requiredAdminUserName.getText());
            Assert.assertEquals("Enter your password", adminManagement.requiredAdminPassword.getText());

        }
    }






