package stepdefinitions.us_23;

public class Empty {
}
