package baseurls;

public class BaseUrl {
}
